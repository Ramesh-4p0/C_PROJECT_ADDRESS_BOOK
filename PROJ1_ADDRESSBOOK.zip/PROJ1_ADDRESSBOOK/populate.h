#include "contact.h"


void populateAddressBook(AddressBook* addressBook);